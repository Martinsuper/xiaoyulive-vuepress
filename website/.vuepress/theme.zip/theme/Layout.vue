<template lang="pug">
  .theme-container
    Home(v-if="$page.frontmatter.home")
</template>

<script>
import Home from './Home'
export default {
  components: { Home }
}
</script>


<style src="prismjs/themes/prism-tomorrow.css"></style>
<style src="./styles/theme.styl" lang="stylus"></style>
