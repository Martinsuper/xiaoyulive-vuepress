const express = require('express')
const expressStatic = require('express-static')
const cookieParser = require('cookie-parser')
const cookieSession = require('cookie-session')
const bodyParser = require('body-parser')
const consolidate=require('consolidate')
const mysql = require('mysql')

const app = express()

// 开启服务器
let server = app.listen(8088, () => {
  let host = server.address().address
  let port = server.address().port
  console.log("应用实例，访问地址为 http://%s:%s", host, port)
})

// 配置模板引擎
app.set('view engine', 'html'); // 输出什么东西
app.set('views', './views'); // 模板文件放在哪儿
app.engine('html', consolidate.ejs); // 哪种模板引擎

// 数据库链接
const conn = mysql.createConnection({
  host: 'localhost',
  port: 3306,
  user: 'root',
  password: 'root',
  database: 'test'
})

// Cookie
app.use(cookieParser('asdfgqwert'))
let arr = []
for (let i = 0; i < 10000; i++) {
  arr.push('keys_' + Math.random());
}

// Session
app.use(cookieSession({
  name: 'zns_sess_id',
  keys: arr,
  maxAge: 20 * 3600 * 1000
}))

// POST 请求体
app.use(bodyParser.urlencoded({
  extended: false
}))

// 路由
app.get('/', (req, res, next) => {
  // console.log('GET: ', req.query)
  // console.log('POST: ', req.body)
  // console.log('cookies: ', req.cookies)
  // console.log('session: ', req.session)
  // console.log('=======================================')
  conn.query('select * from user', (err, data) => {
    if (err) {
      res.status(500).send('database error').end()
    } else {
      res.datas = data
      next()
    }
  })
})

app.get('/', (req, res)=>{
  console.log(res.datas)
  // 指定渲染模板
  res.render('index.ejs', {datas: res.datas});
})

// 静态资源
app.use(expressStatic('./www'))