用户登录、注册

注册 POST
/user?act=reg&user=xxx&pwd=xxxx

登录 GET
/user?act=login&user=xxx&pwd=xxx

返回
	{"ok": false, "msg": "原因"}
	{"ok": true, "msg": "原因"}

  
对文件访问：
  http://localhost:8080/1.html
  http://localhost:8080/1.js
  http://localhost:8080/1.jpg

对接口访问：
  http://localhost:8080/user?act=xx...
  http://localhost:8080/news?act=xxx...