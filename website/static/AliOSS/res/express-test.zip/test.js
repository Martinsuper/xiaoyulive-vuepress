var path = require('path');

var dir = path.parse('c:\\www\\index.html')
console.log(dir)
