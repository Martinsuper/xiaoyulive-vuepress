const express = require('express')
const bodyParser = require('body-parser')
const multer = require('multer')
const fs = require('fs')
const path = require('path')

const app = express()

app.use(multer({
  dest: './www/upload'
}).any())

// 开启服务器
let server = app.listen(8088, () => {
  let host = server.address().address
  let port = server.address().port
  console.log("应用实例，访问地址为 http://%s:%s", host, port)
})

// 路由
app.post('/', (req, res) => {
  for (let i = 0; i < req.files.length; i++) {
    let file = req.files[i];
    let newName = file.path + path.parse(file.originalname).ext
    fs.rename(file.path, newName, (err) => {
      if (err) {
        res.send('上传失败')
      } else {
        res.send('上传成功')
      }
    })
  }
})
