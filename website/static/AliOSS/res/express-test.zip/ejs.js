const ejs = require('ejs')
const fs = require('fs')

ejs.renderFile('./views/index.ejs', {name: 'xiaoyu'}, (err, data) => {
  if (err) {
    console.log('编译失败')
  } else {
    fs.writeFile('./build/index.html', data, (err) => {
      if (err) {
        console.log('写入失败')
      } else {
        console.log('写入成功')
      }
    })
  }
})


