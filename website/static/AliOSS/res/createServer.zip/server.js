const http = require('http')
const fs = require('fs')
const querystring = require('querystring')
const urlLib = require('url')

var users={}   // {"blue": "123456", "zhangsan": "123456", "lisi": "321321"}

var server=http.createServer((req, res) => {
  // 解析数据
  var str=''
  req.on('data', data => {
    str += data
  })
  req.on('end', () => {
    var obj = urlLib.parse(req.url, true)

    const url = obj.pathname
    const GET = obj.query
    const POST = querystring.parse(str)

    if (url === '/user') {
      // 处理接口请求
      switch (GET.act) {
        case 'reg':
          if (users[GET.user]) {
            // 1.检查用户名是否已经有了
            res.write('{"ok": false, "msg": "此用户已存在"}')
          }else{
            // 2.注册成功，插入 users
            users[GET.user] = GET.pass
            res.write('{"ok": true, "msg": "注册成功"}')
          }
          break
        case 'login':
          if (users[GET.user] === null) {
            // 1.检查用户是否存在
            res.write('{"ok": false, "msg": "此用户不存在"}')
          } else if (users[GET.user] !== GET.pass) {
            // 2.检查用户密码
            res.write('{"ok": false, "msg": "用户名或密码有误"}')
          } else {
            // 3.登录成功
            res.write('{"ok": true, "msg": "登录成功"}')
          }
          break
        default:
          res.write('{"ok": false, "msg": "未知的act"}')
      }
      res.end()
    } else {
      //读取文件
      var file_name = './www' + url
      fs.readFile(file_name, (err, data) => {
        if (err) {
          res.write('404')
        } else {
          res.write(data)
        }
        res.end()
      })
    }
  })
}).listen(8080)
