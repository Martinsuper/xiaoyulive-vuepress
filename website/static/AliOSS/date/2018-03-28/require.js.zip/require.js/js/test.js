define(['jquery'], () => {
  return {
    changeBgColor () {
      $('body').css({'background-color':'#f00'})
    },
    changeTextSize () {
      $('body').css({'font-size':'20px'})
    }
  }
})