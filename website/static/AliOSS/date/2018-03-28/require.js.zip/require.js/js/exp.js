function resetTextColor () {
  $('#text').css({'color':'#000'})
}

const changeTextWeight = () => {
  $('#text').css({'font-weight':'bold'})
}