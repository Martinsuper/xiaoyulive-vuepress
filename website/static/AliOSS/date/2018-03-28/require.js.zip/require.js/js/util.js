define([], function() {
  return {
    changeTextColor () {
      $('#text').css({'color':'#fff'})
    }
  }
})