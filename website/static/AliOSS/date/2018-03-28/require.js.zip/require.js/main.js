require.config({
  'baseUrl': './js/',
  'paths': {
    'jquery': '../lib/jquery-3.3.1.min',
    'test': 'test',
    'util': 'util',
    'css': '../lib/css'
  },
  'shim': {
    'util': {
      'deps' : ['jquery', 'css!../css/style.css']
    },
    'exp': {
      'init': function(){ 
        return { 
          'resetTextColor': resetTextColor, //注意这里不需要加引号 
          'changeTextWeight': changeTextWeight
        }
      }
    }
  }
})

require(['jquery', 'test', 'util', 'exp'], ($, test, util, exp) => {
  $('body').css({'background-color':'#0f0'})
  $('#bgBtn').on('click', () => {
    test.changeBgColor()
  })
  $('#textBtn').on('click', () => {
    test.changeTextSize()
  })
  $('#colorBtn').on('click', () => {
    util.changeTextColor()
  })
  $('#resetBtn').on('click', () => {
    exp.resetTextColor()
  })
  $('#boldBtn').on('click', () => {
    exp.changeTextWeight()
  })
})

