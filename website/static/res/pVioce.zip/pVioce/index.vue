<template>
  <div>
    <div class="controler" @click="play">
      <i class="fa fa-volume-up" v-if="index%3===0"></i>
      <i class="fa fa-volume-down" v-if="index%3===1"></i>
      <i class="fa fa-volume-off" v-if="index%3===2"></i>
      {{this.status === 'play' ? '停止' : '播放'}}
      <span>({{parseInt(duration)}}s)</span>
    </div>
    <audio :src="src" ref="audio">
        您的浏览器版本过低，不支持语音!
    </audio>
    <a v-if="/\.amr/.test(audio.src)" :href="src" ref="amr"></a>
  </div>
</template>

<script>
import amrToBase64 from './amrToBase64'
import RongIMLib from './voice-2.0'
export default {
  props: ['src'],
  data () {
    return {
      audio: '',
      status: 'ready',
      index: 0,
      interval: '',
      duration: 0
    }
  },
  created () {
    if (/\.amr/.test(this.src)) {
      amrToBase64.init(this.src, (data) => {
        // 播放大概时长 用 data.length / 1024
        this.duration = Math.ceil(data.length / 1024)
      })
    }
  },
  mounted () {
    this.audio = this.$refs.audio
    RongIMLib.RongIMVoice.init()
  },
  methods: {
    play () {
      if (this.status === 'ready' || this.status === 'stop') {
        if (/\.amr/.test(this.src)) {
          amrToBase64.init(this.src, (data) => {
            // 播放大概时长 用 data.length / 1024
            this.duration = Math.ceil(data.length / 1024)
            RongIMLib.RongIMVoice.play(data, data.length / 1024)
          })
        } else {
          this.audio.play()
        }
        this.status = 'play'
        this.interval = setInterval(() => {
          this.index ++
          if (this.index / 5 >= this.duration) {
            this.status = 'stop'
            this.index = 0
            clearInterval(this.interval)
          }
        }, 200)
      } else if (this.status === 'play') {
        if (/\.amr/.test(this.src)) {
          RongIMLib.RongIMVoice.stop()
        } else {
          this.audio.pause()
          this.audio.currentTime = 0
        }
        this.status = 'stop'
        clearInterval(this.interval)
        this.index = 0
      }
    }
  },
  watch: {
    audio () {
      if (this.audio !== '') {
        setTimeout(() => {
          if (!isNaN(this.audio.duration)) {
            this.duration = this.audio.duration
          }
        }, 1000)
      }
    }
  }
}
</script>

<style lang="less" scoped>
@import '../../styles/base.less';
@bg_color_main: lighten(@main_color, 4%);
audio {
  display: none;
}
.controler {
  width: 50%;
  margin: 1em 0;
  background-color: @bg_color_main;
  padding: 1em;
  color: #fff;
  border-radius: 1em;
  position: relative;
  text-indent: 1em;
  .fa {
    margin-right: 1em;
    display: inline-block;
    width: 1em;
    font-size: 1.2em;
  }
  &::after {
    content: '';
    position: absolute;
    left: 3em;
    top: -.75em;
    display: inline-block;
    width: 1em;
    height: 1em;
    border-top: 1px solid @bg_color_main;
    border-right: .5em solid transparent;
    border-bottom: .5em solid transparent;
    border-left: 1px solid @bg_color_main;
    transform: rotateZ(45deg);
    background-color: @bg_color_main;
    z-index: 10;
  }
}
</style>
