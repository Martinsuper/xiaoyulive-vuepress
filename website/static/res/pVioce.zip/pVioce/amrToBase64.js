let amrToBase64 = {}

let readBlobAsDataURL = (blob, callback) => {
  var reader = new FileReader()
  reader.onload = function (e) {
    callback(e.target.result)
  }
  reader.readAsDataURL(blob)
}

let fetchBlob = (url, callback) => {
  var xhr = new XMLHttpRequest()
  xhr.open('GET', url)
  xhr.responseType = 'blob'
  xhr.onload = function () {
    callback(this.response)
  }
  xhr.onerror = function () {
    // alert('Failed to fetch ' + url)
  }
  xhr.send()
}

amrToBase64.init = (url, callback) => {
  fetchBlob(url, (data) => {
    readBlobAsDataURL(data, function (dataurl) {
      callback(dataurl)
    })
  })
}

export default amrToBase64
