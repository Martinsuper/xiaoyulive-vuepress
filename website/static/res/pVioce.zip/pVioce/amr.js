let amrPlayer = {}

let gAudioContext = new AudioContext()

function fetchBlob (url, callback) {
  console.log(url)
  var xhr = new XMLHttpRequest()
  xhr.open('GET', url)
  xhr.responseType = 'blob'
  xhr.onload = function () {
    console.log(this.response)
    callback(this.response)
  }
  xhr.onerror = function () {
    // alert('Failed to fetch ' + url)
  }
  xhr.send()
}

function playAmrBlob (blob, callback) {
  readBlob(blob, function (data) {
    playAmrArray(data)
  })
}

function readBlob (blob, callback) {
  var reader = new FileReader()
  reader.onload = function (e) {
    var data = new Uint8Array(e.target.result)
    callback(data)
  }
  reader.readAsArrayBuffer(blob)
}

function playAmrArray (array) {
  var samples = window.AMR.decode(array)
  if (!samples) {
    // alert('Failed to decode!')
    return
  }
  playPcm(samples)
}

function playPcm (samples) {
  var ctx = getAudioContext()
  var src = ctx.createBufferSource()
  var buffer = ctx.createBuffer(1, samples.length, 8000)
  if (buffer.copyToChannel) {
    buffer.copyToChannel(samples, 0, 0)
  } else {
    var channelBuffer = buffer.getChannelData(0)
    channelBuffer.set(samples)
  }
  src.buffer = buffer
  src.connect(ctx.destination)
  src.start()
}

function getAudioContext () {
  if (!gAudioContext) {
    gAudioContext = new window.AudioContext()
  }
  return gAudioContext
}

amrPlayer.play = function (element) {
  fetchBlob(element, (blob) => {
    playAmrBlob(blob)
  })
}

export default amrPlayer
